package com.kh.practice.run;

import com.kh.practice.func.OperatorPractice;

public class Run {

	public static void main(String[] args) {
		OperatorPractice op = new OperatorPractice();
		//op.practice1();
		//op.practice2();
		//op.practice3();
		//op.practice4();
		//op.practice5();
		//op.practice6();
		//op.practice7();
		op.practice8();
	}

}
