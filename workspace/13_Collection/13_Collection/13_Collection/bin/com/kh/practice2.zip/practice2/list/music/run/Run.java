package com.kh.practice2.list.music.run;

import com.kh.practice2.list.music.view.MusicView;

public class Run {

	public static void main(String[] args) {
		MusicView mv = new MusicView();
		mv.mainMenu();

	}

}
