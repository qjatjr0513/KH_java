package com.kh.practice2.list.music.controller;

import java.util.ArrayList;
import java.util.List;

import com.kh.practice2.list.music.model.vo.Music;

public class MusicController {
	private List<Music> list = new ArrayList<Music>();
	
	public int addList(Music music) {
		
		list.add(music);
		
		return 1;
	}
	
	public int addAtZero(Music music) {
		list.add(0 ,music);
		return 1;
	}
	
	public List printAll() {
		return list;
	}
	
	public Music searchMusic(String title) {
		for(Music mc : list) {
			if(mc.getTitle().equals(title)) {
				return mc;
			}			
		}
		return null;
	}
	
	public Music removeMusic(String title) {
		int index = 0;
		Music music = null;
		for(Music mc : list) {
			if(mc.getTitle().equals(title)) {
				music = list.remove(index);
				return music;
			}		
			index++;
		}
		
		return null;
	}
}
