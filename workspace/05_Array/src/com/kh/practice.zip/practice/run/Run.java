package com.kh.practice.run;

import com.kh.practice.array.ArrayPractice;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayPractice ap = new ArrayPractice();
		//ap.practice1();
		//ap.practice2();
		//ap.practice3();
		//ap.practice4();
		//ap.practice5();
		//ap.practice6();
		//ap.practice7();
		//ap.practice8();
		ap.practice9();
	}

}
